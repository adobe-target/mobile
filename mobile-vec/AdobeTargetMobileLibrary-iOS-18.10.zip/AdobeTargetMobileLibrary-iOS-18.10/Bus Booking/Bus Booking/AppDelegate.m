//
//  AppDelegate.m
//  Bus Booking
//
//  Created by Anil Bunkar on 02/07/18.
//  Copyright © 2018 Adobe Systems. All rights reserved.
//

#import "AppDelegate.h"
#import "ADBAdobeTargetMobile.h"

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    [ADBAdobeTargetMobile SDKV5_SHIM_initShimWithClientCode:@"emeaprod3"
                                         withMarketingOrgId:@"065838B35278253A0A490D4C@AdobeOrg"];

    return YES;
}


- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
    [ADBAdobeTargetMobile SDKV5_SHIM_applicationWillResignActive:application];
}


- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}


- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
}


- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    [ADBAdobeTargetMobile SDKV5_SHIM_applicationDidBecomeActive:application];
}


- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

#pragma mark - deep link handlers
- (BOOL)application:(UIApplication *)application handleOpenURL:(NSURL *)url {
    [ADBAdobeTargetMobile SDKV5_SHIM_handleDeepLink:url];
    return YES;
}

- (BOOL)application:(UIApplication *)application openURL:(NSURL *)url options:(NSDictionary<NSString *, id> *)options {
    [ADBAdobeTargetMobile SDKV5_SHIM_handleDeepLink:url];
    return YES;
}

@end
