//
//  main.m
//  Bus Booking
//
//  Created by Anil Bunkar on 02/07/18.
//  Copyright © 2018 Adobe Systems. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
